import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smiddle',
  templateUrl: './smiddle.component.html',
  styleUrls: ['./smiddle.component.css']
})
export class SmiddleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
